<?php
/**
 * Plugin Name: OmniReach Chat
 * Description: Adds your OmniReach chat bubble to every page. Paste your chat token in Settings > OmniReach Chat.
 * Version: 1.0.0
 * License: GPLv2 or later
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    add_options_page('OmniReach Chat', 'OmniReach Chat', 'manage_options', 'omnireach-chat', 'omnireach_chat_page');
});

add_action('admin_init', function () {
    register_setting('omnireach_chat', 'omnireach_chat_token', array(
        'type' => 'string',
        'sanitize_callback' => function ($v) {
            $v = strtolower(trim((string) $v));
            return preg_match('/^[a-f0-9]{48}$/', $v) ? $v : '';
        },
        'default' => '',
    ));
    register_setting('omnireach_chat', 'omnireach_chat_host', array(
        'type' => 'string',
        'sanitize_callback' => function ($v) {
            $v = esc_url_raw(trim((string) $v), array('https'));
            return $v ? untrailingslashit($v) : 'https://app.galactech.pro';
        },
        'default' => 'https://app.galactech.pro',
    ));
});

function omnireach_chat_page() {
    if (!current_user_can('manage_options')) { return; }
    ?>
    <div class="wrap">
        <h1>OmniReach Chat</h1>
        <p>In OmniReach open Channels, Web chat, and copy the <strong>token</strong> (the 48 characters after data-token=). Also add this website's address to the allowed websites there.</p>
        <form method="post" action="options.php">
            <?php settings_fields('omnireach_chat'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="omnireach_chat_token">Chat token</label></th>
                    <td><input type="text" id="omnireach_chat_token" name="omnireach_chat_token" class="regular-text code" value="<?php echo esc_attr(get_option('omnireach_chat_token', '')); ?>" autocomplete="off" /></td></tr>
                <tr><th scope="row"><label for="omnireach_chat_host">OmniReach address</label></th>
                    <td><input type="url" id="omnireach_chat_host" name="omnireach_chat_host" class="regular-text" value="<?php echo esc_attr(get_option('omnireach_chat_host', 'https://app.galactech.pro')); ?>" /></td></tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('wp_footer', function () {
    $token = get_option('omnireach_chat_token', '');
    $host = get_option('omnireach_chat_host', 'https://app.galactech.pro');
    if (!preg_match('/^[a-f0-9]{48}$/', (string) $token) || strpos((string) $host, 'https://') !== 0) { return; }
    printf('<script src="%s" data-token="%s" async></script>', esc_url($host . '/webchat.js'), esc_attr($token));
});
